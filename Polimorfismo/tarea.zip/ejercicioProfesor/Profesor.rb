class Profesor

	attr_accessor :nombre , :dni , :porcentaje_de_aporte

	def initialize(nombre , dni , porcentaje_de_aporte)

		@nombre = nombre
		@dni = dni
		@porcentaje_de_aporte = porcentaje_de_aporte

	end

	def sueldo

	end


end